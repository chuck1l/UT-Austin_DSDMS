DELIMITER $$
CREATE PROCEDURE bank_employees_p()
BEGIN
	INSERT INTO bank_employees_t (
		EMPLOYEE_ID,  
		EMPLOYEE_NAME
    )
    SELECT  
		DISTINCT EMPLOYEE_ID,  
		EMPLOYEE_NAME
	FROM bank_t; 
END;

-- CALL bank_employees_p();